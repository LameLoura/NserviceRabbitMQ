﻿using NServiceBus;

public class MyMessage :
    IMessage
{
}